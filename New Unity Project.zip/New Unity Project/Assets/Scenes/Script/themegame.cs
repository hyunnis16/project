﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class themegame : MonoBehaviour{

    public Button btnPlay;
    public Text txt_boardtheme;


    public GameObject InfoThemes;
    public Text txt_infotheme;
    public GameObject star1;
    public GameObject star2;
    public GameObject star3;

    public string[] NameThemes;
    public int numQuestion;

    private int idthemes;


    // Start is called before the first frame update
    void Start()
    {

        idthemes = 0;
        txt_boardtheme.text = NameThemes[idthemes];
        txt_infotheme.text = "Did you hit x of x questions?";
        InfoThemes.SetActive(false);
        star1.SetActive(false);
        star2.SetActive(false);
        star3.SetActive(false);
        btnPlay.interactable = false;

    }
    
    public void selecthemes (int i)
    {
        idthemes = i;
        txt_boardtheme.text = NameThemes[idthemes];

            int notaFinal=0;     //edit later
            int hitQuestion=0;    //edit later

        txt_infotheme.text = "Did you hit "+hitQuestion.ToString()+" of "+numQuestion.ToString()+" questions?";
        InfoThemes.SetActive(true);
        btnPlay.interactable = true;

    }

    public void game()
    {
        Application.LoadLevel("T"+idthemes.ToString());


    }




}
