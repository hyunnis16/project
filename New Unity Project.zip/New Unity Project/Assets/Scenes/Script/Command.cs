﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Command : MonoBehaviour
{
    public void carriedScene (string nameScene)
    {
        Application.LoadLevel(nameScene);

    }

}
