﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class notaFinal : MonoBehaviour
{

    private int idthemes;

    public Text txtnota;
    public Text txtinfothemes;


    public GameObject star1;
    public GameObject star2;
    public GameObject star3;

    private int notaF;
    private int acertos;



    // Start is called before the first frame update
    void Start()
    {

        idthemes = PlayerPrefs.GetInt("idthemes");
        notaF = PlayerPrefs.GetInt("notaFinalTemp" + idthemes.ToString());
        acertos = PlayerPrefs.GetInt("hitQTemp" + idthemes.ToString());

        txtnota.text = notaF.ToString();
        txtinfothemes.text= "Correct "+acertos.ToString();
        
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
