﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class respond : MonoBehaviour
{
    private int idthemes;

    public Text Question;
    public Text answerA;
    public Text answerB;
    public Text answerC;
    public Text answerD;
    public Text infoAnswer;

    public string[] questions;      //store question
    public string[] alternateA;     //store alternateA
    public string[] alternateB;     //store alternateB
    public string[] alternateC;     //store alternateC
    public string[] alternateD;      //store alternateD
    public string[] correct;            //store alternatecorrect


    private int idQuestion;

    private float hitQ;
    private float questionsss;
    private float media;
    private int notaFinal;


    // Start is called before the first frame update
    void Start()
    {
        idthemes = PlayerPrefs.GetInt("idthemes");
        idQuestion = 0;
        questionsss = questions.Length;

        Question.text = questions[idQuestion];
        answerA.text = alternateA[idQuestion];
        answerB.text = alternateB[idQuestion];
        answerC.text = alternateC[idQuestion];
        answerD.text = alternateD[idQuestion];

        infoAnswer.text = "Answer " + (idQuestion + 1).ToString() + " of " + questionsss.ToString() + " Questions.";


    }

    public void answer (string alternate)
    {
        if (alternate == "A")
        {

            //execute answer A
            if(alternateA[idQuestion] == correct[idQuestion])
            {
                hitQ += 1;
            }


        }

        else if (alternate == "B")
        {

            //execute answer B
            if (alternateA[idQuestion] == correct[idQuestion])
            {
                hitQ += 1;
            }
        }

        else if (alternate == "C")
        {

            //execute answer C
            if (alternateA[idQuestion] == correct[idQuestion])
            {
                hitQ += 1;
            }
        }

        else if (alternate == "D")
        {

            //execute answer D
            if (alternateA[idQuestion] == correct[idQuestion])
            {
                hitQ += 1;
            }
        }

        nextQuestion();

    }


    void nextQuestion()
    {

        idQuestion += 1;

        if (idQuestion <= (questionsss - 1))
        {

            Question.text = questions[idQuestion];
            answerA.text = alternateA[idQuestion];
            answerB.text = alternateB[idQuestion];
            answerC.text = alternateC[idQuestion];
            answerD.text = alternateD[idQuestion];

            infoAnswer.text = "Answer " + (idQuestion + 1).ToString() + "of " + questionsss.ToString() + " Questions.";

        }

        else
        {
            //what to do if question finish
            media = 10 * (hitQ / questionsss);  //calculate into percent
            notaFinal = Mathf.RoundToInt(media); //round off

            if(notaFinal > PlayerPrefs.GetInt("notaFinal"+idthemes.ToString()))
            {
                PlayerPrefs.SetInt("notaFinal"+idthemes.ToString(),notaFinal);
                PlayerPrefs.SetInt("hitQ"+idthemes.ToString(),(int) hitQ);
            }

            PlayerPrefs.SetInt("notaFinalTemp" + idthemes.ToString(), notaFinal);
            PlayerPrefs.SetInt("hitQTemp" + idthemes.ToString(), (int)hitQ);



            Application.LoadLevel("notaFinal");

        }
    }






}
